package com.example.sdc

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
